function execute() {
    return Response.success([
        {
            title: "男-都市",
            input: "/reading/bookapi/new_category/landing/v/?category_id=1&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-谍战",
            input: "/reading/bookapi/new_category/landing/v/?category_id=507&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-综漫",
            input: "/reading/bookapi/new_category/landing/v/?category_id=465&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-玄幻",
            input: "/reading/bookapi/new_category/landing/v/?category_id=7&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-武侠",
            input: "/reading/bookapi/new_category/landing/v/?category_id=16&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-大佬",
            input: "/reading/bookapi/new_category/landing/v/?category_id=520&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-历史",
            input: "/reading/bookapi/new_category/landing/v/?category_id=12&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-大小姐",
            input: "/reading/bookapi/new_category/landing/v/?category_id=519&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-体育",
            input: "/reading/bookapi/new_category/landing/v/?category_id=15&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-鉴宝",
            input: "/reading/bookapi/new_category/landing/v/?category_id=17&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-神豪",
            input: "/reading/bookapi/new_category/landing/v/?category_id=20&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-赘婿",
            input: "/reading/bookapi/new_category/landing/v/?category_id=25&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-神医",
            input: "/reading/bookapi/new_category/landing/v/?category_id=26&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-战神",
            input: "/reading/bookapi/new_category/landing/v/?category_id=27&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-海岛",
            input: "/reading/bookapi/new_category/landing/v/?category_id=40&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-奶爸",
            input: "/reading/bookapi/new_category/landing/v/?category_id=42&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-洪荒",
            input: "/reading/bookapi/new_category/landing/v/?category_id=66&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-三国",
            input: "/reading/bookapi/new_category/landing/v/?category_id=67&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-无限流",
            input: "/reading/bookapi/new_category/landing/v/?category_id=70&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-诸天万界",
            input: "/reading/bookapi/new_category/landing/v/?category_id=71&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-大唐",
            input: "/reading/bookapi/new_category/landing/v/?category_id=73&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-宠物",
            input: "/reading/bookapi/new_category/landing/v/?category_id=74&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-外卖",
            input: "/reading/bookapi/new_category/landing/v/?category_id=75&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-剑道",
            input: "/reading/bookapi/new_category/landing/v/?category_id=80&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-都市修真",
            input: "/reading/bookapi/new_category/landing/v/?category_id=124&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-明朝",
            input: "/reading/bookapi/new_category/landing/v/?category_id=126&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-玄幻脑洞",
            input: "/reading/bookapi/new_category/landing/v/?category_id=257&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-传统玄幻",
            input: "/reading/bookapi/new_category/landing/v/?category_id=258&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-奇幻仙侠",
            input: "/reading/bookapi/new_category/landing/v/?category_id=259&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-都市脑洞",
            input: "/reading/bookapi/new_category/landing/v/?category_id=262&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-都市种田",
            input: "/reading/bookapi/new_category/landing/v/?category_id=263&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-历史脑洞",
            input: "/reading/bookapi/new_category/landing/v/?category_id=272&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-历史古代",
            input: "/reading/bookapi/new_category/landing/v/?category_id=273&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-奥特同人",
            input: "/reading/bookapi/new_category/landing/v/?category_id=367&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-破案",
            input: "/reading/bookapi/new_category/landing/v/?category_id=505&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-灵异",
            input: "/reading/bookapi/new_category/landing/v/?category_id=100&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-火影",
            input: "/reading/bookapi/new_category/landing/v/?category_id=368&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-海贼",
            input: "/reading/bookapi/new_category/landing/v/?category_id=370&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-家庭",
            input: "/reading/bookapi/new_category/landing/v/?category_id=125&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-神奇宝贝",
            input: "/reading/bookapi/new_category/landing/v/?category_id=371&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-穿越",
            input: "/reading/bookapi/new_category/landing/v/?category_id=37&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-网游",
            input: "/reading/bookapi/new_category/landing/v/?category_id=372&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-西游",
            input: "/reading/bookapi/new_category/landing/v/?category_id=373&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-漫威",
            input: "/reading/bookapi/new_category/landing/v/?category_id=374&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-特种兵",
            input: "/reading/bookapi/new_category/landing/v/?category_id=375&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-龙珠",
            input: "/reading/bookapi/new_category/landing/v/?category_id=376&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-大秦",
            input: "/reading/bookapi/new_category/landing/v/?category_id=377&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-女帝",
            input: "/reading/bookapi/new_category/landing/v/?category_id=378&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-求生",
            input: "/reading/bookapi/new_category/landing/v/?category_id=379&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-聊天群",
            input: "/reading/bookapi/new_category/landing/v/?category_id=381&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-无女主",
            input: "/reading/bookapi/new_category/landing/v/?category_id=391&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-学霸",
            input: "/reading/bookapi/new_category/landing/v/?category_id=82&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-系统",
            input: "/reading/bookapi/new_category/landing/v/?category_id=19&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-衍生同人",
            input: "/reading/bookapi/new_category/landing/v/?category_id=718&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-九叔",
            input: "/reading/bookapi/new_category/landing/v/?category_id=383&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-乡村",
            input: "/reading/bookapi/new_category/landing/v/?category_id=11&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-单女主",
            input: "/reading/bookapi/new_category/landing/v/?category_id=389&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-都市青春",
            input: "/reading/bookapi/new_category/landing/v/?category_id=396&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-美食",
            input: "/reading/bookapi/new_category/landing/v/?category_id=78&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-囤物资",
            input: "/reading/bookapi/new_category/landing/v/?category_id=494&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-双重生",
            input: "/reading/bookapi/new_category/landing/v/?category_id=524&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-重生",
            input: "/reading/bookapi/new_category/landing/v/?category_id=36&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-游戏体育",
            input: "/reading/bookapi/new_category/landing/v/?category_id=746&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-娱乐圈",
            input: "/reading/bookapi/new_category/landing/v/?category_id=43&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-架空",
            input: "/reading/bookapi/new_category/landing/v/?category_id=452&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-扮猪吃虎",
            input: "/reading/bookapi/new_category/landing/v/?category_id=93&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-开局",
            input: "/reading/bookapi/new_category/landing/v/?category_id=453&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-打脸",
            input: "/reading/bookapi/new_category/landing/v/?category_id=522&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-电竞",
            input: "/reading/bookapi/new_category/landing/v/?category_id=508&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-国运",
            input: "/reading/bookapi/new_category/landing/v/?category_id=496&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-武将",
            input: "/reading/bookapi/new_category/landing/v/?category_id=497&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-皇帝",
            input: "/reading/bookapi/new_category/landing/v/?category_id=498&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-神探",
            input: "/reading/bookapi/new_category/landing/v/?category_id=506&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-末世",
            input: "/reading/bookapi/new_category/landing/v/?category_id=68&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-种田",
            input: "/reading/bookapi/new_category/landing/v/?category_id=23&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-断层",
            input: "/reading/bookapi/new_category/landing/v/?category_id=500&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-腹黑",
            input: "/reading/bookapi/new_category/landing/v/?category_id=92&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-宋朝",
            input: "/reading/bookapi/new_category/landing/v/?category_id=501&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-宫廷侯爵",
            input: "/reading/bookapi/new_category/landing/v/?category_id=502&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-清朝",
            input: "/reading/bookapi/new_category/landing/v/?category_id=503&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-钓鱼",
            input: "/reading/bookapi/new_category/landing/v/?category_id=493&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-东方玄幻",
            input: "/reading/bookapi/new_category/landing/v/?category_id=511&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-异世大陆",
            input: "/reading/bookapi/new_category/landing/v/?category_id=512&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-二次元",
            input: "/reading/bookapi/new_category/landing/v/?category_id=39&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-星际",
            input: "/reading/bookapi/new_category/landing/v/?category_id=77&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-年代",
            input: "/reading/bookapi/new_category/landing/v/?category_id=79&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-高武世界",
            input: "/reading/bookapi/new_category/landing/v/?category_id=513&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-直播",
            input: "/reading/bookapi/new_category/landing/v/?category_id=69&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-灵气复苏",
            input: "/reading/bookapi/new_category/landing/v/?category_id=514&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-推理",
            input: "/reading/bookapi/new_category/landing/v/?category_id=61&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-无敌",
            input: "/reading/bookapi/new_category/landing/v/?category_id=384&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-末日求生",
            input: "/reading/bookapi/new_category/landing/v/?category_id=515&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-空间",
            input: "/reading/bookapi/new_category/landing/v/?category_id=44&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-都市异能",
            input: "/reading/bookapi/new_category/landing/v/?category_id=516&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-四合院",
            input: "/reading/bookapi/new_category/landing/v/?category_id=495&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-校花",
            input: "/reading/bookapi/new_category/landing/v/?category_id=385&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-天才",
            input: "/reading/bookapi/new_category/landing/v/?category_id=90&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-反派",
            input: "/reading/bookapi/new_category/landing/v/?category_id=369&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-修仙",
            input: "/reading/bookapi/new_category/landing/v/?category_id=517&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-盗墓",
            input: "/reading/bookapi/new_category/landing/v/?category_id=81&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-特工",
            input: "/reading/bookapi/new_category/landing/v/?category_id=518&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-克苏鲁",
            input: "/reading/bookapi/new_category/landing/v/?category_id=705&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-悬疑灵异",
            input: "/reading/bookapi/new_category/landing/v/?category_id=751&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-都市生活",
            input: "/reading/bookapi/new_category/landing/v/?category_id=2&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-科幻",
            input: "/reading/bookapi/new_category/landing/v/?category_id=8&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-职场",
            input: "/reading/bookapi/new_category/landing/v/?category_id=127&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-悬疑",
            input: "/reading/bookapi/new_category/landing/v/?category_id=10&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-影视小说",
            input: "/reading/bookapi/new_category/landing/v/?category_id=45&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-诗歌散文",
            input: "/reading/bookapi/new_category/landing/v/?category_id=46&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-生活",
            input: "/reading/bookapi/new_category/landing/v/?category_id=48&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-社会科学",
            input: "/reading/bookapi/new_category/landing/v/?category_id=50&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-科技",
            input: "/reading/bookapi/new_category/landing/v/?category_id=52&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-经济管理",
            input: "/reading/bookapi/new_category/landing/v/?category_id=53&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-教育",
            input: "/reading/bookapi/new_category/landing/v/?category_id=54&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-成功励志",
            input: "/reading/bookapi/new_category/landing/v/?category_id=56&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-文化历史",
            input: "/reading/bookapi/new_category/landing/v/?category_id=62&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-都市日常",
            input: "/reading/bookapi/new_category/landing/v/?category_id=261&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-穿书",
            input: "/reading/bookapi/new_category/landing/v/?category_id=382&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-抗战谍战",
            input: "/reading/bookapi/new_category/landing/v/?category_id=504&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-搞笑轻松",
            input: "/reading/bookapi/new_category/landing/v/?category_id=778&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-游戏主播",
            input: "/reading/bookapi/new_category/landing/v/?category_id=509&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "男-悬疑脑洞",
            input: "/reading/bookapi/new_category/landing/v/?category_id=539&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "女-宫斗宅斗",
            input: "/reading/bookapi/new_category/landing/v/?category_id=246&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-古代言情",
            input: "/reading/bookapi/new_category/landing/v/?category_id=5&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-前世今生",
            input: "/reading/bookapi/new_category/landing/v/?category_id=523&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-玄幻言情",
            input: "/reading/bookapi/new_category/landing/v/?category_id=248&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-幻想言情",
            input: "/reading/bookapi/new_category/landing/v/?category_id=32&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-现言脑洞",
            input: "/reading/bookapi/new_category/landing/v/?category_id=267&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-现代言情",
            input: "/reading/bookapi/new_category/landing/v/?category_id=3&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-都市脑洞",
            input: "/reading/bookapi/new_category/landing/v/?category_id=262&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-古言脑洞",
            input: "/reading/bookapi/new_category/landing/v/?category_id=253&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-豪门总裁",
            input: "/reading/bookapi/new_category/landing/v/?category_id=29&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-豪门世家",
            input: "/reading/bookapi/new_category/landing/v/?category_id=473&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-豪门爽文",
            input: "/reading/bookapi/new_category/landing/v/?category_id=745&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-相爱相杀",
            input: "/reading/bookapi/new_category/landing/v/?category_id=483&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-破镜重圆",
            input: "/reading/bookapi/new_category/landing/v/?category_id=475&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-职场婚恋",
            input: "/reading/bookapi/new_category/landing/v/?category_id=750&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-一见钟情",
            input: "/reading/bookapi/new_category/landing/v/?category_id=477&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-青梅竹马",
            input: "/reading/bookapi/new_category/landing/v/?category_id=387&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-久别重逢",
            input: "/reading/bookapi/new_category/landing/v/?category_id=839&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-悬疑恋爱",
            input: "/reading/bookapi/new_category/landing/v/?category_id=747&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-职场商战",
            input: "/reading/bookapi/new_category/landing/v/?category_id=485&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-异世穿越",
            input: "/reading/bookapi/new_category/landing/v/?category_id=464&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-情有独钟",
            input: "/reading/bookapi/new_category/landing/v/?category_id=456&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-女扮男装",
            input: "/reading/bookapi/new_category/landing/v/?category_id=388&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-日久生情",
            input: "/reading/bookapi/new_category/landing/v/?category_id=474&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-天作之合",
            input: "/reading/bookapi/new_category/landing/v/?category_id=455&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-契约婚姻",
            input: "/reading/bookapi/new_category/landing/v/?category_id=471&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-古色古香",
            input: "/reading/bookapi/new_category/landing/v/?category_id=877&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-古灵精怪",
            input: "/reading/bookapi/new_category/landing/v/?category_id=459&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-家长里短",
            input: "/reading/bookapi/new_category/landing/v/?category_id=862&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-可盐可甜",
            input: "/reading/bookapi/new_category/landing/v/?category_id=454&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-双向奔赴",
            input: "/reading/bookapi/new_category/landing/v/?category_id=476&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-发家致富",
            input: "/reading/bookapi/new_category/landing/v/?category_id=840&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-扮猪吃虎",
            input: "/reading/bookapi/new_category/landing/v/?category_id=93&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-游戏体育",
            input: "/reading/bookapi/new_category/landing/v/?category_id=746&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-衍生同人",
            input: "/reading/bookapi/new_category/landing/v/?category_id=718&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-双女主",
            input: "/reading/bookapi/new_category/landing/v/?category_id=704&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-大佬",
            input: "/reading/bookapi/new_category/landing/v/?category_id=520&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-神探",
            input: "/reading/bookapi/new_category/landing/v/?category_id=506&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-乡村",
            input: "/reading/bookapi/new_category/landing/v/?category_id=11&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-电竞",
            input: "/reading/bookapi/new_category/landing/v/?category_id=508&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-养崽",
            input: "/reading/bookapi/new_category/landing/v/?category_id=847&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-快穿",
            input: "/reading/bookapi/new_category/landing/v/?category_id=24&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-四合院",
            input: "/reading/bookapi/new_category/landing/v/?category_id=495&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-双重生",
            input: "/reading/bookapi/new_category/landing/v/?category_id=524&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-双男主",
            input: "/reading/bookapi/new_category/landing/v/?category_id=275&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-钓鱼",
            input: "/reading/bookapi/new_category/landing/v/?category_id=493&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-综漫",
            input: "/reading/bookapi/new_category/landing/v/?category_id=465&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-推理",
            input: "/reading/bookapi/new_category/landing/v/?category_id=61&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-白切黑",
            input: "/reading/bookapi/new_category/landing/v/?category_id=853&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-同人",
            input: "/reading/bookapi/new_category/landing/v/?category_id=538&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-穿越",
            input: "/reading/bookapi/new_category/landing/v/?category_id=37&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-娱乐圈",
            input: "/reading/bookapi/new_category/landing/v/?category_id=43&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-重生",
            input: "/reading/bookapi/new_category/landing/v/?category_id=36&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-家庭",
            input: "/reading/bookapi/new_category/landing/v/?category_id=125&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-逃婚",
            input: "/reading/bookapi/new_category/landing/v/?category_id=480&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-职场",
            input: "/reading/bookapi/new_category/landing/v/?category_id=127&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-兽世",
            input: "/reading/bookapi/new_category/landing/v/?category_id=72&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-病娇",
            input: "/reading/bookapi/new_category/landing/v/?category_id=380&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-强强",
            input: "/reading/bookapi/new_category/landing/v/?category_id=478&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-将军",
            input: "/reading/bookapi/new_category/landing/v/?category_id=492&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-冰山",
            input: "/reading/bookapi/new_category/landing/v/?category_id=468&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-双面",
            input: "/reading/bookapi/new_category/landing/v/?category_id=469&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-王妃",
            input: "/reading/bookapi/new_category/landing/v/?category_id=85&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-盗墓",
            input: "/reading/bookapi/new_category/landing/v/?category_id=81&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-虐文",
            input: "/reading/bookapi/new_category/landing/v/?category_id=95&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-甜宠",
            input: "/reading/bookapi/new_category/landing/v/?category_id=96&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-年龄差",
            input: "/reading/bookapi/new_category/landing/v/?category_id=848&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-无脑爽",
            input: "/reading/bookapi/new_category/landing/v/?category_id=850&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-打脸",
            input: "/reading/bookapi/new_category/landing/v/?category_id=522&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-清穿",
            input: "/reading/bookapi/new_category/landing/v/?category_id=76&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-无CP",
            input: "/reading/bookapi/new_category/landing/v/?category_id=392&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-明星",
            input: "/reading/bookapi/new_category/landing/v/?category_id=486&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-末世",
            input: "/reading/bookapi/new_category/landing/v/?category_id=68&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-美食",
            input: "/reading/bookapi/new_category/landing/v/?category_id=78&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-魂穿",
            input: "/reading/bookapi/new_category/landing/v/?category_id=852&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-囤物资",
            input: "/reading/bookapi/new_category/landing/v/?category_id=494&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-虐渣",
            input: "/reading/bookapi/new_category/landing/v/?category_id=457&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-宠妻",
            input: "/reading/bookapi/new_category/landing/v/?category_id=30&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-今穿古",
            input: "/reading/bookapi/new_category/landing/v/?category_id=463&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-女强",
            input: "/reading/bookapi/new_category/landing/v/?category_id=86&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-年代",
            input: "/reading/bookapi/new_category/landing/v/?category_id=79&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-空间",
            input: "/reading/bookapi/new_category/landing/v/?category_id=44&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-反派",
            input: "/reading/bookapi/new_category/landing/v/?category_id=369&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-无敌",
            input: "/reading/bookapi/new_category/landing/v/?category_id=384&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-医术",
            input: "/reading/bookapi/new_category/landing/v/?category_id=247&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-星际",
            input: "/reading/bookapi/new_category/landing/v/?category_id=77&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-腹黑",
            input: "/reading/bookapi/new_category/landing/v/?category_id=92&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-暗恋",
            input: "/reading/bookapi/new_category/landing/v/?category_id=482&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-民国",
            input: "/reading/bookapi/new_category/landing/v/?category_id=390&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-灵异",
            input: "/reading/bookapi/new_category/landing/v/?category_id=100&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-二次元",
            input: "/reading/bookapi/new_category/landing/v/?category_id=39&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-系统",
            input: "/reading/bookapi/new_category/landing/v/?category_id=19&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-公主",
            input: "/reading/bookapi/new_category/landing/v/?category_id=83&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-忠犬",
            input: "/reading/bookapi/new_category/landing/v/?category_id=865&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-双洁",
            input: "/reading/bookapi/new_category/landing/v/?category_id=702&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-团宠",
            input: "/reading/bookapi/new_category/landing/v/?category_id=94&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-皇后",
            input: "/reading/bookapi/new_category/landing/v/?category_id=84&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-天才",
            input: "/reading/bookapi/new_category/landing/v/?category_id=90&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-种田",
            input: "/reading/bookapi/new_category/landing/v/?category_id=23&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-直播",
            input: "/reading/bookapi/new_category/landing/v/?category_id=69&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-HE",
            input: "/reading/bookapi/new_category/landing/v/?category_id=484&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-大小姐",
            input: "/reading/bookapi/new_category/landing/v/?category_id=519&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-武侠",
            input: "/reading/bookapi/new_category/landing/v/?category_id=16&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-穿书",
            input: "/reading/bookapi/new_category/landing/v/?category_id=382&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-都市",
            input: "/reading/bookapi/new_category/landing/v/?category_id=1&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-校花",
            input: "/reading/bookapi/new_category/landing/v/?category_id=385&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-无女主",
            input: "/reading/bookapi/new_category/landing/v/?category_id=391&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-律师",
            input: "/reading/bookapi/new_category/landing/v/?category_id=488&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-破案",
            input: "/reading/bookapi/new_category/landing/v/?category_id=505&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-校园",
            input: "/reading/bookapi/new_category/landing/v/?category_id=4&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-医生",
            input: "/reading/bookapi/new_category/landing/v/?category_id=487&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-古穿今",
            input: "/reading/bookapi/new_category/landing/v/?category_id=462&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-作精",
            input: "/reading/bookapi/new_category/landing/v/?category_id=521&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-学霸",
            input: "/reading/bookapi/new_category/landing/v/?category_id=82&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-独宠",
            input: "/reading/bookapi/new_category/landing/v/?category_id=460&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-毒医",
            input: "/reading/bookapi/new_category/landing/v/?category_id=491&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-嫡女",
            input: "/reading/bookapi/new_category/landing/v/?category_id=88&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-皇叔",
            input: "/reading/bookapi/new_category/landing/v/?category_id=87&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-厨娘",
            input: "/reading/bookapi/new_category/landing/v/?category_id=490&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-精灵",
            input: "/reading/bookapi/new_category/landing/v/?category_id=89&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-替身",
            input: "/reading/bookapi/new_category/landing/v/?category_id=470&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-婚恋",
            input: "/reading/bookapi/new_category/landing/v/?category_id=34&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-闪婚",
            input: "/reading/bookapi/new_category/landing/v/?category_id=466&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-萌宝",
            input: "/reading/bookapi/new_category/landing/v/?category_id=28&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-马甲",
            input: "/reading/bookapi/new_category/landing/v/?category_id=266&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-逃荒",
            input: "/reading/bookapi/new_category/landing/v/?category_id=557&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-带球跑",
            input: "/reading/bookapi/new_category/landing/v/?category_id=479&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-隐婚",
            input: "/reading/bookapi/new_category/landing/v/?category_id=467&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-群穿",
            input: "/reading/bookapi/new_category/landing/v/?category_id=461&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-护短",
            input: "/reading/bookapi/new_category/landing/v/?category_id=458&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-影视小说",
            input: "/reading/bookapi/new_category/landing/v/?category_id=45&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-诗歌散文",
            input: "/reading/bookapi/new_category/landing/v/?category_id=46&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-文学小说",
            input: "/reading/bookapi/new_category/landing/v/?category_id=47&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-生活",
            input: "/reading/bookapi/new_category/landing/v/?category_id=48&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-社会科学",
            input: "/reading/bookapi/new_category/landing/v/?category_id=50&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-科技",
            input: "/reading/bookapi/new_category/landing/v/?category_id=52&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-经济管理",
            input: "/reading/bookapi/new_category/landing/v/?category_id=53&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-教育",
            input: "/reading/bookapi/new_category/landing/v/?category_id=54&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-成功励志",
            input: "/reading/bookapi/new_category/landing/v/?category_id=56&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
        {
            title: "女-文化历史",
            input: "/reading/bookapi/new_category/landing/v/?category_id=62&offset={{page}}&sub_category_id&genre_type=0&limit=10&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=2",
            script: "gen2.js"
        },
    ]);
}