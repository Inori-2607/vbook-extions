function execute() {
    return Response.success([
        {
            title: "Đơn nữ chính",
            input: "/reading/bookapi/new_category/landing/v/?category_id=389&offset={{page}}&sub_category_id&genre_type=0&limit=20&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "Đô Thị",
            input: "/reading/bookapi/new_category/landing/v/?category_id=1&offset={{page}}&sub_category_id&genre_type=0&limit=20&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "Đô thị não động",
            input: "/reading/bookapi/new_category/landing/v/?category_id=262&offset={{page}}&sub_category_id&genre_type=0&limit=20&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "Huyền Huyễn",
            input: "/reading/bookapi/new_category/landing/v/?category_id=7&offset={{page}}&sub_category_id&genre_type=0&limit=20&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "Huyền Huyễn Não Động",
            input: "/reading/bookapi/new_category/landing/v/?category_id=257&offset={{page}}&sub_category_id&genre_type=0&limit=20&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "Ngành giải trí",
            input: "/reading/bookapi/new_category/landing/v/?category_id=43&offset={{page}}&sub_category_id&genre_type=0&limit=20&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "Thần hào",
            input: "/reading/bookapi/new_category/landing/v/?category_id=20&offset={{page}}&sub_category_id&genre_type=0&limit=20&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "Vai ác",
            input: "/reading/bookapi/new_category/landing/v/?category_id=369&offset={{page}}&sub_category_id&genre_type=0&limit=20&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "Đô thị tu chân",
            input: "/reading/bookapi/new_category/landing/v/?category_id=124&offset={{page}}&sub_category_id&genre_type=0&limit=20&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
        {
            title: "Linh khí khôi phục",
            input: "/reading/bookapi/new_category/landing/v/?category_id=514&offset={{page}}&sub_category_id&genre_type=0&limit=20&source=front_category&front_page_selected_category&no_need_all_tag=true&query_gender=1",
            script: "gen2.js"
        },
    ]);
}
