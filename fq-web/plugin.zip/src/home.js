function execute() {
    return Response.success([
        {title: "都市",input: "&category_id=1&gender=1",script: "gen3.js"},
    ]);
}