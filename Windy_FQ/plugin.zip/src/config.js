let config_host = "http://localhost:9999";
let config_host2 = "https://fanqienovel.com"